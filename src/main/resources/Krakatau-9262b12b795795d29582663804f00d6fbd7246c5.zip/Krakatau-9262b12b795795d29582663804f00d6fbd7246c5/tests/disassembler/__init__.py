# Mapping from test name -> tuple of argument lists.
registry = {
    'AnachAttrBadCP': ([],),
    'AnachAttrBadLowLbl': ([],),
    'AnachAttrExtraData': ([],),
    'AnachAttrTruncated': ([],),
    'AnachAttrStackMapExtra': ([],),
    'AnachAttrStackMapLbl': ([],),
    'AnachAttrStackMapTruncated': ([],),
    'AnachAttrStackMapTwice': ([],),
    'AnachAttrStackMapVTCode': ([],),


    'AnnotationsTest': ([],),
    'LineNumbersTest': ([],),
    'MethodParametersTest': ([],),
    'Primes': (['2'], ['3'], ['55555']),
    'SelfInner': ([],),
}
